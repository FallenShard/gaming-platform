﻿(function () {
    'use strict';

    var users = [];
    var games = [];
    var devs = [];

    var selUser = null;
    var selGame = null;
    var selDev = null;

    var selUserEl = null;
    var selGameEl = null;
    var selDevEl = null;


    function enableTabs() {
        $('#user-tabs a').click(function (e) {
            e.preventDefault();
            $(this).tab('show');
        });
    }

    function documentInit() {
        $("#header-div").load("header.html", function () {
            headerBar.init();
        });

        // Some protection against intruders, uncomment later
        //if (sessionStorage.activeUser) {
        //    var activeUserString = sessionStorage.activeUser;
        //    var activeUser = JSON.parse(activeUserString);
        //    if (activeUser.status !== "Admin")
        //        window.location.replace("index.html");
        //}
        //else
        //    window.location.replace("index.html");

        enableTabs();

        initUsers();
        initGames();
        initDevs();
    }

    function initUsers() {
        $.ajax({
            type: "GET",
            url: "Service.svc/GetAllUsers",
            data: null,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: true,
            success: function (receivedData) {
                onUsersSuccess(receivedData);
            },
            error: function (result) {
                console.log("Error performing ajax " + result);
            }
        });
    }

    function onUsersSuccess(receivedData) {
        var $userList = $("#user-list");
        $userList.empty();
        users = [];
        selUser = null;
        selUserEl = null;

        for (var i = 0; i < receivedData.length; i++) {
            try {
                var item = JSON.parse(receivedData[i]);
            }
            catch (exception) {
                console.log("error parsing json");
                continue;
            }

            users.push(item);

            var listElement = document.createElement("a");
            $(listElement).attr("class", "list-group-item");
            $(listElement).attr("value", i);
            $(listElement).html(item.username);
            $(listElement).click(function () {
                var ind = parseInt($(this).attr("value"));

                if (selUserEl)
                    selUserEl.removeClass("active");

                selUserEl = $(this);
                selUserEl.addClass("active");
                selUser = users[ind];
                
                console.log(selUser);
            });

            $userList.append(listElement);
        }
    }

    function initGames() {
        $.ajax({
            type: "GET",
            url: "Service.svc/GetAllGames",
            data: null,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: true,
            success: function (receivedData) {
                onGamesSuccess(receivedData);
            },
            error: function (result) {
                console.log("Error performing ajax " + result);
            }
        });
    }

    function onGamesSuccess(receivedData) {
        var $gameList = $("#game-list");
        $gameList.empty();
        games = [];
        selGame = null;
        selGameEl = null;

        for (var i = 0; i < receivedData.length; i++) {
            try {
                var item = JSON.parse(receivedData[i]);
            }
            catch (exception) {
                console.log("error parsing json");
                continue;
            }

            games.push(item);

            var listElement = document.createElement("a");
            $(listElement).attr("class", "list-group-item");
            $(listElement).attr("value", i);
            $(listElement).html(item.title);
            $(listElement).click(function () {
                var ind = parseInt($(this).attr("value"));

                if (selGameEl)
                    selGameEl.removeClass("active");

                selGameEl = $(this);
                selGameEl.addClass("active");
                selGame = games[ind];

                console.log(selGame);
            });

            $gameList.append(listElement);
        }
    }

    function initDevs() {
        $.ajax({
            type: "GET",
            url: "Service.svc/GetAllDevelopers",
            data: null,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: true,
            success: function (receivedData) {
                onDevsSuccess(receivedData);
            },
            error: function (result) {
                console.log("Error performing ajax " + result);
            }
        });
    }

    function onDevsSuccess(receivedData) {
        var $devList = $("#dev-list");
        $devList.empty();
        devs = [];
        selDev = null;
        selDevEl = null;

        for (var i = 0; i < receivedData.length; i++) {
            try {
                var item = JSON.parse(receivedData[i]);
            }
            catch (exception) {
                console.log("error parsing json");
                continue;
            }

            devs.push(item);

            var listElement = document.createElement("a");
            $(listElement).attr("class", "list-group-item");
            $(listElement).attr("value", i);
            $(listElement).html(item.name);
            $(listElement).click(function () {
                var ind = parseInt($(this).attr("value"));

                if (selDevEl)
                    selDevEl.removeClass("active");

                selDevEl = $(this);
                selDevEl.addClass("active");
                selDev = games[ind];

                console.log(selDev);
            });

            $devList.append(listElement);
        }
    }




    $(document).ready(documentInit);
})();